# GExpDes
Interface Grtáfica ExpDes 
